const abi = [`function associate()`, `function dissociate()`];
export default abi;
